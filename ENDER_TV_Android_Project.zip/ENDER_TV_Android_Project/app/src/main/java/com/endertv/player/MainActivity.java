package com.endertv.player;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.text.InputType;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private ExoPlayer player;
    private PlayerView playerView;
    private EditText playlistUrl;
    private LinearLayout channelList;
    private TextView status;
    private final ArrayList<String> names = new ArrayList<>();
    private final ArrayList<String> urls = new ArrayList<>();
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 24, 39));
        getWindow().setNavigationBarColor(Color.rgb(16, 24, 39));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(14), dp(12), dp(14), dp(12));
        page.setBackgroundColor(Color.rgb(16, 24, 39));

        TextView title = new TextView(this);
        title.setText("ENDER TV"); title.setTextColor(Color.WHITE); title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); page.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Canlı yayın oynatıcı • Yasal M3U listesi ekleyin");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setTextSize(12); page.addView(subtitle);

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, dp(220));
        vp.topMargin = dp(12); page.addView(playerView, vp);
        playlistUrl = new EditText(this);
        playlistUrl.setSingleLine(true); playlistUrl.setTextColor(Color.WHITE);
        playlistUrl.setHintTextColor(Color.LTGRAY);
        playlistUrl.setHint("M3U yayın listesi HTTPS bağlantısı");
        playlistUrl.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        page.addView(playlistUrl, new LinearLayout.LayoutParams(-1, dp(52)));
        Button load = new Button(this); load.setText("YAYIN LİSTESİNİ YÜKLE"); page.addView(load);
        status = new TextView(this); status.setText("Başlamak için yasal M3U bağlantınızı ekleyin.");
        status.setTextColor(Color.rgb(203, 213, 225)); status.setPadding(0, dp(6), 0, dp(6)); page.addView(status);
        ScrollView scroll = new ScrollView(this);
        channelList = new LinearLayout(this); channelList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(channelList); page.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(page);
        player = new ExoPlayer.Builder(this).build(); playerView.setPlayer(player);
        load.setOnClickListener(v -> loadPlaylist());
    }

    private void loadPlaylist() {
        String address = playlistUrl.getText().toString().trim();
        if (!address.startsWith("https://")) {
            status.setText("Güvenlik için HTTPS ile başlayan bir M3U bağlantısı girin."); return;
        }
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(playlistUrl.getWindowToken(), 0);
        status.setText("Yayın listesi yükleniyor…");
        new Thread(() -> {
            ArrayList<String> nn = new ArrayList<>(); ArrayList<String> uu = new ArrayList<>();
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection)new URL(address).openConnection();
                conn.setConnectTimeout(12000); conn.setReadTimeout(15000);
                conn.setRequestProperty("User-Agent", "ENDER-TV/1.0");
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                    String line, pending = "Kanal";
                    while ((line = br.readLine()) != null) {
                        line = line.trim();
                        if (line.startsWith("#EXTINF")) {
                            int comma = line.lastIndexOf(','); pending = comma >= 0 ? line.substring(comma + 1).trim() : "Kanal";
                        } else if (line.startsWith("https://") && !line.startsWith("#")) {
                            nn.add(pending); uu.add(line); pending = "Kanal";
                        }
                    }
                }
                runOnUiThread(() -> {
                    names.clear(); names.addAll(nn); urls.clear(); urls.addAll(uu); channelList.removeAllViews();
                    if (urls.isEmpty()) { status.setText("Kanal bulunamadı. M3U bağlantısını kontrol edin."); return; }
                    status.setText(urls.size() + " kanal yüklendi. İzlemek için dokunun.");
                    for (int i = 0; i < names.size(); i++) {
                        final int index = i; Button b = new Button(this); b.setText(names.get(i));
                        b.setAllCaps(false); channelList.addView(b); b.setOnClickListener(v -> playChannel(index));
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Yüklenemedi. Bağlantıyı ve interneti kontrol edin."));
            } finally { if (conn != null) conn.disconnect(); }
        }).start();
    }
    private void playChannel(int i) {
        status.setText("Açılıyor: " + names.get(i)); player.setMediaItem(MediaItem.fromUri(urls.get(i))); player.prepare(); player.play();
    }
    @Override protected void onDestroy() { if (player != null) player.release(); super.onDestroy(); }
}
