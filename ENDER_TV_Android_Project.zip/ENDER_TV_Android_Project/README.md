# ENDER TV (başlangıç projesi)

Android 6+ hedefleyen basit M3U oynatıcı başlangıcı. Android 12 / Samsung M51 için derlenmesi amaçlanmıştır; gerçek cihazda ve canlı yayınlarla henüz test edilmemiştir.

## Özellikler
- ENDER TV adıyla Android uygulama arayüzü
- HTTPS M3U bağlantısı yükleme
- M3U içindeki HTTPS yayınlarını listeleme ve Media3 ile oynatma

## APK oluşturma
`.github/workflows/build.yml` GitHub Actions ile `app-debug.apk` üretmeyi dener. GitHub deposuna bu dosyaların tamamını ekleyip `main` dalına gönderin. Sonra Actions sekmesindeki iş akışını açıp başarılı çalıştırmanın Artifacts bölümünden APK'yı indirin.

## Sınırlamalar
- Bu proje başlangıç örneğidir, doğrulanmış veya imzalı mağaza sürümü değildir.
- Yalnızca size ait veya kullanma izniniz bulunan yasal yayın bağlantılarını ekleyin.
- Şimdilik yalnızca HTTPS bağlantılarını işler; bazı M3U listeleri, DRM, HLS/DASH biçimleri veya özel başlık isteyen yayınlar çalışmayabilir.
- Android Auto araç ekranında video oynatmayı garanti etmez. Araçta video yalnızca park hâlindeyken ve araç sisteminin izin verdiği biçimde kullanılmalıdır.
